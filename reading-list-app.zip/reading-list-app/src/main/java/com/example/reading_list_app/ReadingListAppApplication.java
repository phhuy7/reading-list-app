package com.example.reading_list_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadingListAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadingListAppApplication.class, args);
	}

}
